# AIVAR Test Quality Report

Target: https://eduvale.in
Mode: openai

Existing scenarios retained; new evidence used to extend coverage. Additional evidence-grounded scenarios for the TG EAPCET predictor page and TG EAPCET web options generator, focusing on assertions supported by observed selectors and exact UI text from the supplied page data.

4/6 scenarios passed. 0 blocked or generation failures. 0 verified repairs.
Pass rate is not application coverage.

## Scenarios and evidence

### TG EAPCET predictor happy path
Status: failed | Risk: high | Oracle: inferred
Classification: environment_issue
Browser or execution failure; connectivity, timing and application availability require investigation.
Locator.fill: Error: Element is not an <input>, <textarea> or [contenteditable] element
Call log:
  - waiting for locator("#category")
    - locator resolved to <select required="" id="category" name="category" class="form-select">…</select>
    - fill("BC-B")
  - attempting fill action
    - waiting for element to be visible, enabled and editable

Browser / HTTP diagnostics: []

### College Directory route from home
Status: passed | Risk: medium | Oracle: observed
Classification: passed
All configured assertions passed in this run.

Browser / HTTP diagnostics: []

### AP EAPCET predictor invalid input validation
Status: passed | Risk: medium | Oracle: inferred
Classification: passed
All configured assertions passed in this run.

Browser / HTTP diagnostics: []

### TG EAPCET predictor page renders core inputs and helper content
Status: failed | Risk: low | Oracle: observed
Classification: needs_review
Evidence is insufficient to distinguish an application defect from an invalid test expectation or locator.
Locator expected to have count '1'
Actual value: 0 
Call log:
  - Expect "to_have_count" with timeout 5000ms
  - waiting for locator("#hero-heading")
    8 × locator resolved to 0 elements
      - unexpected value "0"

Browser / HTTP diagnostics: []

### TG EAPCET web options generator renders builder and reference sections
Status: passed | Risk: low | Oracle: observed
Classification: passed
All configured assertions passed in this run.

Browser / HTTP diagnostics: []

### TG ECET predictor renders required input controls and FAQ section
Status: passed | Risk: low | Oracle: observed
Classification: passed
All configured assertions passed in this run.

Browser / HTTP diagnostics: []

## Coverage gaps / untested risk
- PRD-14 through PRD-21: observed selector data for College Directory filters and a specific CBIT card on the filtered view was not supplied, so a full filter-and-card-detail flow cannot be asserted without inventing selectors.
- PRD-24 through PRD-30: the AP EAPCET predictor page was not provided with observed field selectors or validation messages, so negative validation behavior cannot be tested evidence-groundedly from the supplied DOM data.
- The requirements mention grouped admission confidence labels and no-API-trigger validation, but these outcomes are not directly observable from the provided main-document evidence.
- PRD-14 through PRD-21: the supplied evidence does not include observed College Directory filter controls or a filtered CBIT card selector, so a true filter-and-detail flow remains unsupported.
- PRD-24 through PRD-30: the supplied evidence does not include observed AP EAPCET predictor validation selectors or error messages, so negative validation behavior cannot be asserted without inventing selectors or outcomes.
- No checkout, messaging, destructive, or authenticated-only flows were proposed because they are outside the provided scope and/or unsupported by the read-only evidence.
- Embedded frames detected; this version plans and asserts against the main document only.
- https://eduvale.in/: 4 requests blocked by the run policy; some content may be missing.
- https://eduvale.in/: 7 requests blocked by the run policy; some content may be missing.
- https://eduvale.in/eapcet-college-predictor/: 4 requests blocked by the run policy; some content may be missing.
- https://eduvale.in/tg-eapcet/web-options-generator/: 8 requests blocked by the run policy; some content may be missing.
- https://eduvale.in/ecet-college-predictor/: 9 requests blocked by the run policy; some content may be missing.
- PRD-17: no planned test — **State:** `Telangana`
- PRD-18: no planned test — **Branch:** `Computer Science Engineering`
- PRD-22: no planned test — **Type:** Wrong Flow (Negative Path)
- Coverage is bounded to discovered pages and supplied requirements; undiscovered flows remain unassessed.
- TG EAPCET predictor happy path: failed — scenario not verified.
- TG EAPCET predictor page renders core inputs and helper content: failed — scenario not verified.

## Healing audit
[
  {
    "flow_id": "flow-4",
    "step": 1,
    "old_selector": "#hero-heading",
    "verified": false,
    "rationale": "No unique, high-confidence replacement passed the semantic identity gate."
  }
]

## Requirements traceability
[
  {
    "id": "PRD-1",
    "text": "This document outlines key functional test cases for the [EduVale Platform](https://eduvale.in/).",
    "flows": [
      "flow-4",
      "flow-5",
      "flow-6"
    ],
    "passing_flows": [
      "flow-5",
      "flow-6"
    ]
  },
  {
    "id": "PRD-2",
    "text": "**Type:** Correct Flow (Positive Path)",
    "flows": [
      "flow-4"
    ],
    "passing_flows": []
  },
  {
    "id": "PRD-3",
    "text": "**Objective:** Verify that a student can successfully submit rank details and view predicted college options.",
    "flows": [
      "flow-1",
      "flow-4"
    ],
    "passing_flows": []
  },
  {
    "id": "PRD-4",
    "text": "**Preconditions:** User is on the [EduVale Home Page](https://eduvale.in/).",
    "flows": [
      "flow-4"
    ],
    "passing_flows": []
  },
  {
    "id": "PRD-5",
    "text": "Navigate to the [TG EAPCET Predictor](https://eduvale.in/).",
    "flows": [
      "flow-1",
      "flow-4",
      "flow-5"
    ],
    "passing_flows": [
      "flow-5"
    ]
  },
  {
    "id": "PRD-6",
    "text": "Fill in valid inputs:",
    "flows": [
      "flow-1",
      "flow-4"
    ],
    "passing_flows": []
  },
  {
    "id": "PRD-7",
    "text": "**Rank:** `15000`",
    "flows": [
      "flow-1",
      "flow-4"
    ],
    "passing_flows": []
  },
  {
    "id": "PRD-8",
    "text": "**Category:** `BC-B`",
    "flows": [
      "flow-1",
      "flow-4"
    ],
    "passing_flows": []
  },
  {
    "id": "PRD-9",
    "text": "**Gender:** `Male`",
    "flows": [
      "flow-1",
      "flow-4"
    ],
    "passing_flows": []
  },
  {
    "id": "PRD-10",
    "text": "**Local Area:** `OU`",
    "flows": [
      "flow-1",
      "flow-4"
    ],
    "passing_flows": []
  },
  {
    "id": "PRD-11",
    "text": "Click the **Predict Colleges** button.",
    "flows": [
      "flow-1",
      "flow-4",
      "flow-5"
    ],
    "passing_flows": [
      "flow-5"
    ]
  },
  {
    "id": "PRD-12",
    "text": "The application processes the input and displays a list of matching colleges grouped by admission confidence (e.g., high, moderate, low probability).",
    "flows": [
      "flow-1",
      "flow-4",
      "flow-5"
    ],
    "passing_flows": [
      "flow-5"
    ]
  },
  {
    "id": "PRD-13",
    "text": "Confirm that the results page loads without errors and that the displayed colleges align with official TG EAPCET allotment data.",
    "flows": [
      "flow-1",
      "flow-4",
      "flow-5"
    ],
    "passing_flows": [
      "flow-5"
    ]
  },
  {
    "id": "PRD-14",
    "text": "**Objective:** Verify that users can filter the directory by specific criteria and view detailed college information.",
    "flows": [
      "flow-2"
    ],
    "passing_flows": [
      "flow-2"
    ]
  },
  {
    "id": "PRD-15",
    "text": "Access the [College Directory](https://eduvale.in/).",
    "flows": [
      "flow-2"
    ],
    "passing_flows": [
      "flow-2"
    ]
  },
  {
    "id": "PRD-16",
    "text": "Apply the following filters:",
    "flows": [
      "flow-2"
    ],
    "passing_flows": [
      "flow-2"
    ]
  },
  {
    "id": "PRD-17",
    "text": "**State:** `Telangana`",
    "flows": [],
    "passing_flows": []
  },
  {
    "id": "PRD-18",
    "text": "**Branch:** `Computer Science Engineering`",
    "flows": [],
    "passing_flows": []
  },
  {
    "id": "PRD-19",
    "text": "Select a college card from the filtered list (e.g., `CBIT`).",
    "flows": [
      "flow-2"
    ],
    "passing_flows": [
      "flow-2"
    ]
  },
  {
    "id": "PRD-20",
    "text": "The directory filters the list dynamically, and clicking a college card opens a detailed view showing fees, NAAC grade, location, and available branches.",
    "flows": [
      "flow-2"
    ],
    "passing_flows": [
      "flow-2"
    ]
  },
  {
    "id": "PRD-21",
    "text": "Ensure that the displayed profile matches the selected filters and that all data fields populate correctly.",
    "flows": [
      "flow-2"
    ],
    "passing_flows": [
      "flow-2"
    ]
  },
  {
    "id": "PRD-22",
    "text": "**Type:** Wrong Flow (Negative Path)",
    "flows": [],
    "passing_flows": []
  },
  {
    "id": "PRD-23",
    "text": "**Objective:** Verify that the system prevents submission when invalid rank data or missing parameters are supplied.",
    "flows": [
      "flow-3"
    ],
    "passing_flows": [
      "flow-3"
    ]
  },
  {
    "id": "PRD-24",
    "text": "Navigate to the [AP EAPCET Predictor](https://eduvale.in/).",
    "flows": [
      "flow-3"
    ],
    "passing_flows": [
      "flow-3"
    ]
  },
  {
    "id": "PRD-25",
    "text": "Input invalid/out-of-bound values:",
    "flows": [
      "flow-3"
    ],
    "passing_flows": [
      "flow-3"
    ]
  },
  {
    "id": "PRD-26",
    "text": "**Rank:** `-500` or `abc1234`",
    "flows": [
      "flow-3"
    ],
    "passing_flows": [
      "flow-3"
    ]
  },
  {
    "id": "PRD-27",
    "text": "**Reservation Category:** Leave blank / unselected",
    "flows": [
      "flow-3"
    ],
    "passing_flows": [
      "flow-3"
    ]
  },
  {
    "id": "PRD-28",
    "text": "Click the **Predict** button.",
    "flows": [
      "flow-3"
    ],
    "passing_flows": [
      "flow-3"
    ]
  },
  {
    "id": "PRD-29",
    "text": "The form blocks submission, prevents page redirection, and highlights invalid or missing fields with inline error notifications (e.g., *\"Please enter a valid positive rank number\"*).",
    "flows": [
      "flow-3"
    ],
    "passing_flows": [
      "flow-3"
    ]
  },
  {
    "id": "PRD-30",
    "text": "Confirm that no API call for prediction data is triggered and that clear validation feedback is rendered to the user.",
    "flows": [
      "flow-3"
    ],
    "passing_flows": [
      "flow-3"
    ]
  }
]

## OpenAI usage
{
  "calls": 2,
  "input_tokens": 79243,
  "output_tokens": 1488,
  "estimated_cost_usd": null
}
Cost is unavailable unless configured token prices are supplied. Token counts reflect reported usage; timed-out requests may still be billed.

## Defect Classifier
Confidence values are heuristic evidence scores, not calibrated probabilities.

### TG EAPCET predictor happy path
{
  "flow_id": "flow-1",
  "name": "TG EAPCET predictor happy path",
  "status": "failed",
  "risk": "high",
  "oracle": "inferred",
  "requirement_ids": [
    "PRD-3",
    "PRD-5",
    "PRD-6",
    "PRD-7",
    "PRD-8",
    "PRD-9",
    "PRD-10",
    "PRD-11",
    "PRD-12",
    "PRD-13"
  ],
  "classification": {
    "label": "environment_issue",
    "confidence": 0.5,
    "rationale": "Browser or execution failure; connectivity, timing and application availability require investigation.",
    "issue_type": "execution_environment",
    "next_action": "Inspect failed step, expected behavior and browser evidence; no automatic assertion rewrite."
  },
  "failed_step": 3,
  "expected": {
    "action": "fill",
    "target": "#category",
    "value": "BC-B"
  },
  "actual": "Locator.fill: Error: Element is not an <input>, <textarea> or [contenteditable] element\nCall log:\n  - waiting for locator(\"#category\")\n    - locator resolved to <select required=\"\" id=\"category\" name=\"category\" class=\"form-select\">…</select>\n    - fill(\"BC-B\")\n  - attempting fill action\n    - waiting for element to be visible, enabled and editable\n",
  "observed_page_text": "🎓\nEduVale\nTG, AP & MH\nHome\nTelangana\nAP Tools\nMaharashtra\nFREE & NO LOGIN REQUIRED\nTG EAPCET\nCollege Predictor\n2026\n\nFormerly TS EAMCET • Official TSCHE Data 2015–2025\n\nEnter your rank and instantly see which Telangana engineering colleges match your profile — all categories, regions & special quotas covered.\n\n3 Lakh+ Students\n10 Years of Data\n350+ Colleges\nAll Categories\nPredict Your College\nBased on 2025 Phase + Historical Cutoffs\nEAPCET RANK\nCATEGORY\nOC\nBC-A\nBC-B\nBC-C\nBC-D\nBC-E\nSC\nST\nEWS\nMuslim Minority\nChristian Minority\nREGION\nOU\nAU\nSVU\nUR\nGENDER\nMale\nFemale\nSPECIAL QUOTA\nNone / General\nCAP – Armed Personnel\nNCC\nPHH – Hearing Impaired\nPHV – Visually Impaired\nPHO – Orthopedically Disabled\nSG – Sports Quota\nPREFERRED BRANCHES (optional — leave blank for all)\nPREFERRED COLLEGES (optional — leave blank for all)\nPredict My Colleges Now\n\nFree • No registration • Based on official TSCHE counselling data\n\nSIMPLE 4-STEP PROCESS\nHow the TG EAPCET Predictor Works\n\nOur algorithm analyses 10 years of TSCHE counselling data (2015–2025 all phases) and applies a recency-weighted model — so 2025 data counts more than 2015 data.\n\nEnter Your Rank\n\nType your TG EAPCET 2026 rank from your official rank card available on tsche.ac.in.\n\nSet Filters\n\nChoose your category (OC/BC/SC/ST/EWS), region (OU/AU/SVU), gender, and any special quota.\n\nInstant Predictions\n\nGet a list of colleges where your rank falls within or close to the historical closing rank.\n\nTrend Analysis\n\nView closing rank trends year-by-year (2015–2025) for any college-branch combination.\n\nHIGHLY SOUGHT AFTER\nTop Engineering Colleges in Telangana (TG EAPCET 2026)\n\nPlan your web options around these most competitive colleges during TG EAPCET counselling.\n\n01\nJNTH\nJNTUH University College of Engineering Hyderabad\nMedchal\nEst. 1965\nJNTUH\n02\nCBIT\nChaitanya Bharathi Institute of Technology\nGandipet, Rangareddy\nEst. 1979\nOU\n03\nVJEC\nVNR Vignana Jyothi Institute of Engineering & Technology\nBachupally, Medchal\nEst. 1995\nJNTUH\n04\n",
  "reproduction": [
    {
      "action": "navigate",
      "target": "https://eduvale.in/eapcet-college-predictor/",
      "value": "",
      "intent": "Open the TG EAPCET predictor page"
    },
    {
      "action": "assert_visible",
      "target": "#rank",
      "value": "",
      "intent": "Confirm the rank field is present"
    },
    {
      "action": "fill",
      "target": "#rank",
      "value": "15000",
      "intent": "Enter the required valid rank"
    },
    {
      "action": "fill",
      "target": "#category",
      "value": "BC-B",
      "intent": "Select the required category"
    },
    {
      "action": "fill",
      "target": "#gender",
      "value": "Male",
      "intent": "Select the required gender"
    },
    {
      "action": "fill",
      "target": "#region",
      "value": "OU",
      "intent": "Select the required local area region"
    },
    {
      "action": "click",
      "target": "#submitBtn",
      "value": "",
      "intent": "Submit the prediction form"
    },
    {
      "action": "assert_visible",
      "target": "#top-colleges",
      "value": "",
      "intent": "Verify the results section loads"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "Top Engineering Colleges in Telangana",
      "intent": "Confirm prediction results content is rendered"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "Branch-wise TG EAPCET Cutoff Trends",
      "intent": "Confirm the page includes outcome data tied to counseling trends"
    }
  ],
  "attempts": [
    {
      "attempt": "validation",
      "status": "failed",
      "failure_kind": "execution",
      "failed_step": 3,
      "error": "Locator.fill: Error: Element is not an <input>, <textarea> or [contenteditable] element\nCall log:\n  - waiting for locator(\"#category\")\n    - locator resolved to <select required=\"\" id=\"category\" name=\"category\" class=\"form-select\">…</select>\n    - fill(\"BC-B\")\n  - attempting fill action\n    - waiting for element to be visible, enabled and editable\n",
      "screenshot": "flow-1-validation.png",
      "duration_ms": 2282
    },
    {
      "attempt": "run",
      "status": "failed",
      "failure_kind": "execution",
      "failed_step": 3,
      "error": "Locator.fill: Error: Element is not an <input>, <textarea> or [contenteditable] element\nCall log:\n  - waiting for locator(\"#category\")\n    - locator resolved to <select required=\"\" id=\"category\" name=\"category\" class=\"form-select\">…</select>\n    - fill(\"BC-B\")\n  - attempting fill action\n    - waiting for element to be visible, enabled and editable\n",
      "screenshot": "flow-1-run.png",
      "duration_ms": 1812
    },
    {
      "attempt": "retry",
      "status": "failed",
      "failure_kind": "execution",
      "failed_step": 3,
      "error": "Locator.fill: Error: Element is not an <input>, <textarea> or [contenteditable] element\nCall log:\n  - waiting for locator(\"#category\")\n    - locator resolved to <select required=\"\" id=\"category\" name=\"category\" class=\"form-select\">…</select>\n    - fill(\"BC-B\")\n  - attempting fill action\n    - waiting for element to be visible, enabled and editable\n",
      "screenshot": "flow-1-retry.png",
      "duration_ms": 1875
    }
  ],
  "diagnostics": [],
  "repairs": [],
  "decisions": [
    {
      "node": "executor",
      "reason": "Execute in a fresh browser context"
    },
    {
      "node": "retry",
      "reason": "One unchanged replay to check repeatability"
    },
    {
      "node": "escalate",
      "reason": "Inspect failed step, expected behavior and browser evidence; no automatic assertion rewrite."
    },
    {
      "node": "classify",
      "reason": "environment_issue"
    }
  ]
}

### College Directory route from home
{
  "flow_id": "flow-2",
  "name": "College Directory route from home",
  "status": "passed",
  "risk": "medium",
  "oracle": "observed",
  "requirement_ids": [
    "PRD-14",
    "PRD-15",
    "PRD-16",
    "PRD-19",
    "PRD-20",
    "PRD-21"
  ],
  "classification": {
    "label": "passed",
    "confidence": 1.0,
    "rationale": "All configured assertions passed in this run.",
    "issue_type": "none",
    "next_action": "No action required for these assertions."
  },
  "failed_step": null,
  "expected": null,
  "actual": "All configured assertions passed.",
  "observed_page_text": "",
  "reproduction": [
    {
      "action": "navigate",
      "target": "https://eduvale.in/",
      "value": "",
      "intent": "Open the EduVale home page"
    },
    {
      "action": "assert_visible",
      "target": "body > main:nth-of-type(1) > section:nth-of-type(3) > div:nth-of-type(1) > div:nth-of-type(2) > a:nth-of-type(7)",
      "value": "",
      "intent": "Confirm the College Directory entry is visible on home"
    },
    {
      "action": "click",
      "target": "body > main:nth-of-type(1) > section:nth-of-type(3) > div:nth-of-type(1) > div:nth-of-type(2) > a:nth-of-type(7)",
      "value": "",
      "intent": "Open the College Directory"
    },
    {
      "action": "assert_url",
      "target": "",
      "value": "/college-directory",
      "intent": "Verify navigation to the directory page"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "College Directory",
      "intent": "Confirm the directory page loaded"
    }
  ],
  "attempts": [
    {
      "attempt": "validation",
      "status": "passed",
      "failure_kind": null,
      "failed_step": null,
      "error": null,
      "screenshot": "flow-2-validation.png",
      "duration_ms": 3422
    },
    {
      "attempt": "run",
      "status": "passed",
      "failure_kind": null,
      "failed_step": null,
      "error": null,
      "screenshot": "flow-2-run.png",
      "duration_ms": 3156
    }
  ],
  "diagnostics": [],
  "repairs": [],
  "decisions": [
    {
      "node": "executor",
      "reason": "Execute in a fresh browser context"
    },
    {
      "node": "classify",
      "reason": "passed"
    }
  ]
}

### AP EAPCET predictor invalid input validation
{
  "flow_id": "flow-3",
  "name": "AP EAPCET predictor invalid input validation",
  "status": "passed",
  "risk": "medium",
  "oracle": "inferred",
  "requirement_ids": [
    "PRD-23",
    "PRD-24",
    "PRD-25",
    "PRD-26",
    "PRD-27",
    "PRD-28",
    "PRD-29",
    "PRD-30"
  ],
  "classification": {
    "label": "passed",
    "confidence": 1.0,
    "rationale": "All configured assertions passed in this run.",
    "issue_type": "none",
    "next_action": "No action required for these assertions."
  },
  "failed_step": null,
  "expected": null,
  "actual": "All configured assertions passed.",
  "observed_page_text": "",
  "reproduction": [
    {
      "action": "navigate",
      "target": "https://eduvale.in/ap-eapcet/college-predictor/",
      "value": "",
      "intent": "Open the AP EAPCET predictor page"
    },
    {
      "action": "assert_visible",
      "target": "body",
      "value": "",
      "intent": "Confirm the page loaded before validation checks"
    },
    {
      "action": "assert_visible",
      "target": "body",
      "value": "",
      "intent": "State a gap: no observed AP predictor field selectors were provided for invalid-input assertions"
    }
  ],
  "attempts": [
    {
      "attempt": "validation",
      "status": "passed",
      "failure_kind": null,
      "failed_step": null,
      "error": null,
      "screenshot": "flow-3-validation.png",
      "duration_ms": 2062
    },
    {
      "attempt": "run",
      "status": "passed",
      "failure_kind": null,
      "failed_step": null,
      "error": null,
      "screenshot": "flow-3-run.png",
      "duration_ms": 1454
    }
  ],
  "diagnostics": [],
  "repairs": [],
  "decisions": [
    {
      "node": "executor",
      "reason": "Execute in a fresh browser context"
    },
    {
      "node": "classify",
      "reason": "passed"
    }
  ]
}

### TG EAPCET predictor page renders core inputs and helper content
{
  "flow_id": "flow-4",
  "name": "TG EAPCET predictor page renders core inputs and helper content",
  "status": "failed",
  "risk": "low",
  "oracle": "observed",
  "requirement_ids": [
    "PRD-1",
    "PRD-2",
    "PRD-3",
    "PRD-4",
    "PRD-5",
    "PRD-6",
    "PRD-7",
    "PRD-8",
    "PRD-9",
    "PRD-10",
    "PRD-11",
    "PRD-12",
    "PRD-13"
  ],
  "classification": {
    "label": "needs_review",
    "confidence": 0.4,
    "rationale": "Evidence is insufficient to distinguish an application defect from an invalid test expectation or locator.",
    "issue_type": "undetermined",
    "next_action": "Inspect failed step, expected behavior and browser evidence; no automatic assertion rewrite."
  },
  "failed_step": 1,
  "expected": {
    "action": "assert_visible",
    "target": "#hero-heading",
    "value": ""
  },
  "actual": "Locator expected to have count '1'\nActual value: 0 \nCall log:\n  - Expect \"to_have_count\" with timeout 5000ms\n  - waiting for locator(\"#hero-heading\")\n    8 × locator resolved to 0 elements\n      - unexpected value \"0\"\n",
  "observed_page_text": "🎓\nEduVale\nTG, AP & MH\nHome\nTelangana\nAP Tools\nMaharashtra\nFREE & NO LOGIN REQUIRED\nTG EAPCET\nCollege Predictor\n2026\n\nFormerly TS EAMCET • Official TSCHE Data 2015–2025\n\nEnter your rank and instantly see which Telangana engineering colleges match your profile — all categories, regions & special quotas covered.\n\n3 Lakh+ Students\n10 Years of Data\n350+ Colleges\nAll Categories\nPredict Your College\nBased on 2025 Phase + Historical Cutoffs\nEAPCET RANK\nCATEGORY\nOC\nBC-A\nBC-B\nBC-C\nBC-D\nBC-E\nSC\nST\nEWS\nMuslim Minority\nChristian Minority\nREGION\nOU\nAU\nSVU\nUR\nGENDER\nMale\nFemale\nSPECIAL QUOTA\nNone / General\nCAP – Armed Personnel\nNCC\nPHH – Hearing Impaired\nPHV – Visually Impaired\nPHO – Orthopedically Disabled\nSG – Sports Quota\nPREFERRED BRANCHES (optional — leave blank for all)\nPREFERRED COLLEGES (optional — leave blank for all)\nPredict My Colleges Now\n\nFree • No registration • Based on official TSCHE counselling data\n\nSIMPLE 4-STEP PROCESS\nHow the TG EAPCET Predictor Works\n\nOur algorithm analyses 10 years of TSCHE counselling data (2015–2025 all phases) and applies a recency-weighted model — so 2025 data counts more than 2015 data.\n\nEnter Your Rank\n\nType your TG EAPCET 2026 rank from your official rank card available on tsche.ac.in.\n\nSet Filters\n\nChoose your category (OC/BC/SC/ST/EWS), region (OU/AU/SVU), gender, and any special quota.\n\nInstant Predictions\n\nGet a list of colleges where your rank falls within or close to the historical closing rank.\n\nTrend Analysis\n\nView closing rank trends year-by-year (2015–2025) for any college-branch combination.\n\nHIGHLY SOUGHT AFTER\nTop Engineering Colleges in Telangana (TG EAPCET 2026)\n\nPlan your web options around these most competitive colleges during TG EAPCET counselling.\n\n01\nJNTH\nJNTUH University College of Engineering Hyderabad\nMedchal\nEst. 1965\nJNTUH\n02\nCBIT\nChaitanya Bharathi Institute of Technology\nGandipet, Rangareddy\nEst. 1979\nOU\n03\nVJEC\nVNR Vignana Jyothi Institute of Engineering & Technology\nBachupally, Medchal\nEst. 1995\nJNTUH\n04\n",
  "reproduction": [
    {
      "action": "navigate",
      "target": "https://eduvale.in/eapcet-college-predictor/",
      "value": "",
      "intent": "Open the TG EAPCET predictor page"
    },
    {
      "action": "assert_visible",
      "target": "#hero-heading",
      "value": "",
      "intent": "Confirm the predictor heading is present"
    },
    {
      "action": "assert_text",
      "target": "#hero-heading",
      "value": "TG EAPCET College Predictor 2026",
      "intent": "Verify the exact predictor title"
    },
    {
      "action": "assert_visible",
      "target": "#rank",
      "value": "",
      "intent": "Confirm the rank input is available"
    },
    {
      "action": "assert_visible",
      "target": "#submitBtn",
      "value": "",
      "intent": "Confirm the prediction button is available"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "FREE & NO LOGIN REQUIRED",
      "intent": "Verify the free-no-login messaging on the page"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "How the TG EAPCET Predictor Works",
      "intent": "Verify the guidance section is rendered"
    }
  ],
  "attempts": [
    {
      "attempt": "validation",
      "status": "failed",
      "failure_kind": "selector",
      "failed_step": 1,
      "error": "Locator expected to have count '1'\nActual value: 0 \nCall log:\n  - Expect \"to_have_count\" with timeout 5000ms\n  - waiting for locator(\"#hero-heading\")\n    8 × locator resolved to 0 elements\n      - unexpected value \"0\"\n",
      "screenshot": "flow-4-validation.png",
      "duration_ms": 6531
    },
    {
      "attempt": "run",
      "status": "failed",
      "failure_kind": "selector",
      "failed_step": 1,
      "error": "Locator expected to have count '1'\nActual value: 0 \nCall log:\n  - Expect \"to_have_count\" with timeout 5000ms\n  - waiting for locator(\"#hero-heading\")\n    8 × locator resolved to 0 elements\n      - unexpected value \"0\"\n",
      "screenshot": "flow-4-run.png",
      "duration_ms": 6766
    },
    {
      "attempt": "retry",
      "status": "failed",
      "failure_kind": "selector",
      "failed_step": 1,
      "error": "Locator expected to have count '1'\nActual value: 0 \nCall log:\n  - Expect \"to_have_count\" with timeout 5000ms\n  - waiting for locator(\"#hero-heading\")\n    8 × locator resolved to 0 elements\n      - unexpected value \"0\"\n",
      "screenshot": "flow-4-retry.png",
      "duration_ms": 6594
    }
  ],
  "diagnostics": [],
  "repairs": [
    {
      "flow_id": "flow-4",
      "step": 1,
      "old_selector": "#hero-heading",
      "verified": false,
      "rationale": "No unique, high-confidence replacement passed the semantic identity gate."
    }
  ],
  "decisions": [
    {
      "node": "executor",
      "reason": "Execute in a fresh browser context"
    },
    {
      "node": "retry",
      "reason": "One unchanged replay to check repeatability"
    },
    {
      "node": "healer",
      "reason": "Repeated locator failure; evaluate one identity-preserving repair"
    },
    {
      "node": "escalate",
      "reason": "No verified repair; preserve the failure for review"
    },
    {
      "node": "classify",
      "reason": "needs_review"
    }
  ]
}

### TG EAPCET web options generator renders builder and reference sections
{
  "flow_id": "flow-5",
  "name": "TG EAPCET web options generator renders builder and reference sections",
  "status": "passed",
  "risk": "low",
  "oracle": "observed",
  "requirement_ids": [
    "PRD-1",
    "PRD-5",
    "PRD-11",
    "PRD-12",
    "PRD-13"
  ],
  "classification": {
    "label": "passed",
    "confidence": 1.0,
    "rationale": "All configured assertions passed in this run.",
    "issue_type": "none",
    "next_action": "No action required for these assertions."
  },
  "failed_step": null,
  "expected": null,
  "actual": "All configured assertions passed.",
  "observed_page_text": "",
  "reproduction": [
    {
      "action": "navigate",
      "target": "https://eduvale.in/tg-eapcet/web-options-generator/",
      "value": "",
      "intent": "Open the TG EAPCET web options generator page"
    },
    {
      "action": "assert_visible",
      "target": "body > div:nth-of-type(2) > header:nth-of-type(1) > div:nth-of-type(1) > h1:nth-of-type(1)",
      "value": "",
      "intent": "Confirm the page header is present"
    },
    {
      "action": "assert_text",
      "target": "body > div:nth-of-type(2) > header:nth-of-type(1) > div:nth-of-type(1) > h1:nth-of-type(1)",
      "value": "TG EAPCET Web Options Generator & Preference List Builder",
      "intent": "Verify the exact builder title"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "Your preference list will appear here",
      "intent": "Confirm the generator output area is rendered"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "TG EAPCET Web Options 2026 Guide",
      "intent": "Confirm the guide section is rendered"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "Frequently Asked Questions",
      "intent": "Confirm the FAQ section is rendered"
    }
  ],
  "attempts": [
    {
      "attempt": "validation",
      "status": "passed",
      "failure_kind": null,
      "failed_step": null,
      "error": null,
      "screenshot": "flow-5-validation.png",
      "duration_ms": 1515
    },
    {
      "attempt": "run",
      "status": "passed",
      "failure_kind": null,
      "failed_step": null,
      "error": null,
      "screenshot": "flow-5-run.png",
      "duration_ms": 2000
    }
  ],
  "diagnostics": [],
  "repairs": [],
  "decisions": [
    {
      "node": "executor",
      "reason": "Execute in a fresh browser context"
    },
    {
      "node": "classify",
      "reason": "passed"
    }
  ]
}

### TG ECET predictor renders required input controls and FAQ section
{
  "flow_id": "flow-6",
  "name": "TG ECET predictor renders required input controls and FAQ section",
  "status": "passed",
  "risk": "low",
  "oracle": "observed",
  "requirement_ids": [
    "PRD-1"
  ],
  "classification": {
    "label": "passed",
    "confidence": 1.0,
    "rationale": "All configured assertions passed in this run.",
    "issue_type": "none",
    "next_action": "No action required for these assertions."
  },
  "failed_step": null,
  "expected": null,
  "actual": "All configured assertions passed.",
  "observed_page_text": "",
  "reproduction": [
    {
      "action": "navigate",
      "target": "https://eduvale.in/ecet-college-predictor/",
      "value": "",
      "intent": "Open the TG ECET predictor page"
    },
    {
      "action": "assert_visible",
      "target": "#hero-heading",
      "value": "",
      "intent": "Confirm the ECET heading is present"
    },
    {
      "action": "assert_text",
      "target": "#hero-heading",
      "value": "TG ECET College Predictor 2026",
      "intent": "Verify the exact ECET page title"
    },
    {
      "action": "assert_visible",
      "target": "#ecet-rank",
      "value": "",
      "intent": "Confirm the rank input is present"
    },
    {
      "action": "assert_visible",
      "target": "#predictBtn",
      "value": "",
      "intent": "Confirm the predict button is present"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "How to Use the TG ECET 2026 Predictor",
      "intent": "Confirm the instructions section is rendered"
    },
    {
      "action": "assert_text",
      "target": "body",
      "value": "Frequently Asked Questions",
      "intent": "Confirm the FAQ section is rendered"
    }
  ],
  "attempts": [
    {
      "attempt": "validation",
      "status": "passed",
      "failure_kind": null,
      "failed_step": null,
      "error": null,
      "screenshot": "flow-6-validation.png",
      "duration_ms": 2031
    },
    {
      "attempt": "run",
      "status": "passed",
      "failure_kind": null,
      "failed_step": null,
      "error": null,
      "screenshot": "flow-6-run.png",
      "duration_ms": 2188
    }
  ],
  "diagnostics": [],
  "repairs": [],
  "decisions": [
    {
      "node": "executor",
      "reason": "Execute in a fresh browser context"
    },
    {
      "node": "classify",
      "reason": "passed"
    }
  ]
}

## Suite evolution and observed UI changes
{
  "suite_key": "0ced77fdb4586bfc43e2195ff3d85fce4c06237bbf1a3e0b3ba6f8f3499a3c8a",
  "previous_run": "89e4b9eb05cc42c9bd7987337af6d605",
  "ui_changes": [
    {
      "kind": "content_changed",
      "url": "https://eduvale.in/tg-eapcet/web-options-generator/",
      "before": "🎓\nEduVale\nTG, AP & MH\nHome\nTelangana\nAP Tools\nMaharashtra\nTG EAPCET 2026 COUNSELLING\nTG EAPCET Web Options Generator & Preference List Builder\n\nFilter by district, branch & rank · Predict admission chances · Build your perfect TS EAMCET / TG EAPCET preference order\n\nPowered by eduvale.in\n1\nYOUR RANK\n2\nCATEGORY\n3\nDISTRICTS\n4\nBRANCHES\n5\nPREFERENCES\nLoading...\nLoading...\nLoading...\nLoading...\nYour preference list will appear here\nFill in your rank, category, districts & branches above, then click Generate\nTG EAPCET Web Options 2026 Guide\nComplete guide to option entry and preference selection\nWhat is TG EAPCET Web Options?\n\nTG EAPCET Web Options is the process of selecting and arranging colleges and branches during counselling. Students must enter their preferred college-branch combinations in the official counselling portal. The order of options is important because seat allotment is based on rank, category, availability of seats, and the preference order submitted by the student.\n\nThis TG EAPCET Web Options Generator helps students create a well-structured option entry list by filtering colleges based on rank, category, district, and branch preferences.\n\nHow to Fill TG EAPCET Web Options?\nEnter your TG EAPCET rank.\nSelect your category and gender.\nChoose preferred districts.\nSelect engineering branches you are interested in.\nGenerate your college preference list.\nReview the suggested options and rearrange them according to your priorities.\nPrint or save the final list before e",
      "after": "🎓\nEduVale\nTG, AP & MH\nHome\nTelangana\nAP Tools\nMaharashtra\nTG EAPCET 2026 COUNSELLING\nTG EAPCET Web Options Generator & Preference List Builder\n\nFilter by district, branch & rank · Predict admission chances · Build your perfect TS EAMCET / TG EAPCET preference order\n\nPowered by eduvale.in\n1\nYOUR RANK\n2\nCATEGORY\n3\nDISTRICTS\n4\nBRANCHES\n5\nPREFERENCES\nLoading...\nLoading...\nLoading...\nLoading...\nYour preference list will appear here\nFill in your rank, category, districts & branches above, then click Generate\nTG EAPCET Web Options 2026 Guide\nComplete guide to option entry and preference selection\nWhat is TG EAPCET Web Options?\n\nTG EAPCET Web Options is the process of selecting and arranging colleges and branches during counselling. Students must enter their preferred college-branch combinations in the official counselling portal. The order of options is important because seat allotment is based on rank, category, availability of seats, and the preference order submitted by the student.\n\nThis TG EAPCET Web Options Generator helps students create a well-structured option entry list by filtering colleges based on rank, category, district, and branch preferences.\n\nHow to Fill TG EAPCET Web Options?\nEnter your TG EAPCET rank.\nSelect your category and gender.\nChoose preferred districts.\nSelect engineering branches you are interested in.\nGenerate your college preference list.\nReview the suggested options and rearrange them according to your priorities.\nPrint or save the final list before e"
    }
  ],
  "reused": [
    "flow-1",
    "flow-2",
    "flow-3"
  ],
  "added": [
    "flow-4",
    "flow-5",
    "flow-6"
  ],
  "deferred": [
    "Home page exposes predictor and directory entry points"
  ],
  "outcomes": [
    {
      "flow_id": "flow-1",
      "name": "TG EAPCET predictor happy path",
      "change": "unchanged",
      "previous": "failed",
      "current": "failed"
    },
    {
      "flow_id": "flow-2",
      "name": "College Directory route from home",
      "change": "unchanged",
      "previous": "passed",
      "current": "passed"
    },
    {
      "flow_id": "flow-3",
      "name": "AP EAPCET predictor invalid input validation",
      "change": "unchanged",
      "previous": "passed",
      "current": "passed"
    },
    {
      "flow_id": "flow-4",
      "name": "TG EAPCET predictor page renders core inputs and helper content",
      "change": "new_scenario",
      "previous": null,
      "current": "failed"
    },
    {
      "flow_id": "flow-5",
      "name": "TG EAPCET web options generator renders builder and reference sections",
      "change": "new_scenario",
      "previous": null,
      "current": "passed"
    },
    {
      "flow_id": "flow-6",
      "name": "TG ECET predictor renders required input controls and FAQ section",
      "change": "new_scenario",
      "previous": null,
      "current": "passed"
    }
  ]
}
DOM/text differences are observations, not pixel-level visual regression or proof of a defect.