"""Replay from the project root: python path/to/generated_tests.py"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd()))
from qa_agent.replay import main
if __name__ == "__main__":
    main(Path(__file__).with_name("suite.json"))
