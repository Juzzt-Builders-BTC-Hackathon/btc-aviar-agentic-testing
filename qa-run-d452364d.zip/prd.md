# Test Plan: EduVale Web Application

This document outlines key functional test cases for the [EduVale Platform](https://eduvale.in/).

---

## 1. Test Case: TG EAPCET College Prediction

* **Type:** Correct Flow (Positive Path)
* **Objective:** Verify that a student can successfully submit rank details and view predicted college options.
* **Preconditions:** User is on the [EduVale Home Page](https://eduvale.in/).

### Test Steps
1. Navigate to the [TG EAPCET Predictor](https://eduvale.in/).
2. Fill in valid inputs:
   * **Rank:** `15000`
   * **Category:** `BC-B`
   * **Gender:** `Male`
   * **Local Area:** `OU`
3. Click the **Predict Colleges** button.

### Expected Result
The application processes the input and displays a list of matching colleges grouped by admission confidence (e.g., high, moderate, low probability).

### Verification
Confirm that the results page loads without errors and that the displayed colleges align with official TG EAPCET allotment data.

---

## 2. Test Case: College Directory Search & Filter

* **Type:** Correct Flow (Positive Path)
* **Objective:** Verify that users can filter the directory by specific criteria and view detailed college information.
* **Preconditions:** User is on the [EduVale Home Page](https://eduvale.in/).

### Test Steps
1. Access the [College Directory](https://eduvale.in/).
2. Apply the following filters:
   * **State:** `Telangana`
   * **Branch:** `Computer Science Engineering`
3. Select a college card from the filtered list (e.g., `CBIT`).

### Expected Result
The directory filters the list dynamically, and clicking a college card opens a detailed view showing fees, NAAC grade, location, and available branches.

### Verification
Ensure that the displayed profile matches the selected filters and that all data fields populate correctly.

---

## 3. Test Case: Invalid Input Validation on Rank Predictor

* **Type:** Wrong Flow (Negative Path)
* **Objective:** Verify that the system prevents submission when invalid rank data or missing parameters are supplied.
* **Preconditions:** User is on the [EduVale Home Page](https://eduvale.in/).

### Test Steps
1. Navigate to the [AP EAPCET Predictor](https://eduvale.in/).
2. Input invalid/out-of-bound values:
   * **Rank:** `-500` or `abc1234`
   * **Reservation Category:** Leave blank / unselected
3. Click the **Predict** button.

### Expected Result
The form blocks submission, prevents page redirection, and highlights invalid or missing fields with inline error notifications (e.g., *"Please enter a valid positive rank number"*).

### Verification
Confirm that no API call for prediction data is triggered and that clear validation feedback is rendered to the user.