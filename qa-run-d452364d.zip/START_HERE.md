# AIVAR — start here

Run: d452364d1bda4634b407331e9e291cf5
Status at export: completed

1. Open report.html in your browser, or read report.md, for the Test Quality Report.
2. Inspect defect_report.json for expected/actual behavior, original reproduction,
   classification, attempt screenshots, repair decisions and recommended next actions.
3. Read heal_log.json for proposed and verified locator repairs. A proposal is not
   a repair until its full-flow confirmation passes.
4. Read suite_evolution.json for retained/new cases, regressions and observed UI changes.
5. Read traceability.json and coverage_gaps.json for PRD coverage and untested risks.
6. Consult decision_log.json for timestamped orchestration decisions.

Completed means the pipeline finished, not that all tests passed. Pass rate is not
full application coverage. Classification confidence is heuristic; suspected defects
need review. DOM differences are bounded observations, not pixel-level comparisons.

Partial exports from running, cancelled, interrupted or failed pipelines can lack
final reports. If present, runtime_error.json gives the fatal stage and recovery guidance.

## Replay

From the AIVAR project root, with its Python environment, Playwright browser and
target authentication configured:

    .venv/Scripts/python.exe -m qa_agent.replay "path/to/extracted/suite.json"

On Linux/macOS use .venv/bin/python. Replay uses the exported action suite without
planning calls. The ZIP is not a standalone installer. The original target and
test preconditions must remain available.

PRDs, screenshots and traces can contain application data. Inspect before sharing.
The repository's docs/REPORT_GUIDE.md provides the complete artifact dictionary.
